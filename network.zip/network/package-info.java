/**
 * 
 * Network code. You can play with others.
 *@author Oikmo
 */
package net.maniaticdevs.engine.network;