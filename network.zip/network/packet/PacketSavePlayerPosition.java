package net.maniaticdevs.engine.network.packet;

public class PacketSavePlayerPosition {
	public int id;
	public String userName;
	public float x, y, z;
	public float rotX, rotY, rotZ;
}
