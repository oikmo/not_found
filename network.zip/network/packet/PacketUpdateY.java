package net.maniaticdevs.engine.network.packet;

public class PacketUpdateY {

	public int id;
	public float y;
	
}
