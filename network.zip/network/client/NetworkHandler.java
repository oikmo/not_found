package net.maniaticdevs.engine.network.client;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import javax.swing.JFrame;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryonet.Client;

import net.maniaticdevs.engine.network.packet.LoginRequest;
import net.maniaticdevs.engine.network.packet.LoginResponse;
import net.maniaticdevs.engine.network.packet.Message;
import net.maniaticdevs.engine.network.packet.PacketSavePlayerPosition;
import net.maniaticdevs.engine.network.packet.PacketUpdateX;
import net.maniaticdevs.engine.network.packet.PacketUpdateY;
import net.maniaticdevs.engine.util.Logger;
import net.maniaticdevs.engine.util.Logger.LogLevel;
import net.maniaticdevs.engine.util.math.Vector2;
import net.maniaticdevs.main.Main;

public class NetworkHandler {
	
	public static float rand;

	public static JFrame frame;
	public Random random = new Random();
	
	private int tcpPort;
	private int udpPort;
	private int timeout;
	private String ip;
	
	public Client client;
	private static Kryo kryo;
	
	public OtherPlayer player;
	public Map<Integer, OtherPlayer> players = new HashMap<Integer, OtherPlayer>();
	
	private int tickTimer = 0;
	public static final int NETWORK_PROTOCOL = 1;
	
	private static void registerKryoClasses() {
		kryo.register(LoginRequest.class);
		kryo.register(LoginResponse.class);
		kryo.register(Message.class);
		kryo.register(OtherPlayer.class);
		kryo.register(float[].class);
		kryo.register(byte[].class);
	}
	
	public NetworkHandler(String ipAddress) throws Exception {
		this.ip = ipAddress;
		this.udpPort = 25565;
		this.tcpPort = 25565;
		this.timeout = 500000;
		players = new HashMap<Integer, OtherPlayer>();
		player = new OtherPlayer();
		player.userName = Main.player.name;
		client = new Client();
		kryo = client.getKryo();
		registerKryoClasses();
		connect(ip);
	}
	
	public static void testNetwork(String ipAddress) throws Exception {
		String ip = ipAddress;
		int udpPort = 25565;
		int tcpPort = 25565;
		int timeout = 500000;
		Client client = new Client();
		kryo = client.getKryo();
		registerKryoClasses();
		
		Logger.log(LogLevel.INFO, "Test connecting...");
		client.start();
		client.connect(timeout, ip, tcpPort, udpPort);
		Logger.log(LogLevel.INFO, "Test connected!");
		Logger.log(LogLevel.INFO, "Test disconnecting...");
		client.stop();
		Logger.log(LogLevel.INFO, "Test disconnected.");
	}
	
	public void tick() {
		
		if(tickTimer <= 5) {
			tickTimer++;
		} else {
			tickTimer = 0;
			
			Vector2 pos = Main.player.getPosition();
			player.updatePosition(pos.x, pos.y);
			PacketUpdateX packetX = new PacketUpdateX();
			packetX.x = player.x;
			client.sendUDP(packetX);
			PacketUpdateY packetY = new PacketUpdateY();
			packetY.y = player.y;
			client.sendUDP(packetY);
		}
	}
	
	
	public void update() {
		if(!client.isConnected()) {
			//Main.disconnect(false, Main.lang.translateKey("network.disconnect.ux"));
			return;
		}
		
		if(player.c != null) {
			if(players.containsKey(player.c.getID())) {
				players.remove(player.c.getID());
			}
		}
		
		int x = player.x;
		int y = player.y;
		Vector2 pos = Main.player.getPosition();
		player.updatePosition(pos.x, pos.y);
		
		if(x != player.x) {
			PacketUpdateX packetX = new PacketUpdateX();
			packetX.x = player.x;
			client.sendUDP(packetX);
		}
		
		if(y != player.y) {	
			PacketUpdateY packetY = new PacketUpdateY();
			packetY.y = player.y;
			client.sendUDP(packetY);
		}
	}
	
	public void connect(String ip) throws Exception {
		Logger.log(LogLevel.INFO, "Connecting...");
		client.start();
		client.connect(timeout, ip, tcpPort, udpPort);
		client.addListener(new PlayerClientListener());
		players = new HashMap<Integer, OtherPlayer>();
		LoginRequest request = new LoginRequest();
		request.setUserName(player.userName);
		request.PROTOCOL = NetworkHandler.NETWORK_PROTOCOL;
		client.sendTCP(request);
		
		Logger.log(LogLevel.INFO, "Connected.");
	}
	
	public void disconnect()  {
		if(Main.player != null) {
			PacketSavePlayerPosition data = new PacketSavePlayerPosition();
			data.userName = Main.player.name;
			data.x = Main.player.getPosition().x;
			data.y = Main.player.getPosition().y;
			client.sendTCP(data);
		}
		
		try {
			Thread.sleep(100);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		Logger.log(LogLevel.INFO, "Disconnecting...");
		client.stop();
		Logger.log(LogLevel.INFO, "Disconnected.");
	}
}
