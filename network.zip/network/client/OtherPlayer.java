package net.maniaticdevs.engine.network.client;

import com.esotericsoftware.kryonet.Connection;

public class OtherPlayer {
	
	public Connection c;
	public int id;
	
	public String userName;
	
	public int x, y;
	
	public void updatePosition(int x, int y) {
		this.x = x;
		this.y = y;
	}
}
