package net.maniaticdevs.engine.network.packet;

public class PacketUpdateZ {

	public int id;
	public float z;
	
}
