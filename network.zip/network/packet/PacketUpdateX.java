package net.maniaticdevs.engine.network.packet;

public class PacketUpdateX {
	
	public int id;
	public float x;
}
